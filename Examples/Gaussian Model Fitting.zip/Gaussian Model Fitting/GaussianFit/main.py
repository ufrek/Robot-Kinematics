import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
np.set_printoptions( precision=2 )



#current_directory = os.path.dirname(__file__)  # talks about our file we are in now
#filepath = os.path.join(current_directory, "data", "data/DrawLineOnPaper.csv")

colNames = ['m1', 'm2', 'm3', 'm4', 'm5', 'm6', 'count', 'time']
motorData = pd.read_csv("data/CradleToHome.csv", sep=",")  # ,  usecols=colNames

featureCols = ['m1',  'm2', 'm3',  'm4', 'm5', 'm6',  'time']
#select relevant columnns here
#x = np.array(motorData[motorData.columns[0:5]])
#x = motorData[featureCols].values
#time

n = 269  # input points
k = 14 # changes in direction
fig, ax = plt.subplots(6,1)

def reset_my_index(df):
  res = df[::-1].reset_index(drop=True)
  return(res)

def plotMotor(index):

    Y = motorData[motorData.columns[index]]   # change the column or motor you are analyzing
    np.reshape(Y, Y.size)
    #x = x.values




    #comment out for everything but the backwards sigmoid function. This reverses it so it models correctly
    #Y = reset_my_index(Y)


    X = np.linspace( 0, 1, n ).reshape((n,1))


    A = np.ones((n,1))                          # A = input matrix, used in regression to make predictions (and solve for W)

    center = np.linspace(0,1,k)                     # center = the means that define the position of each kernel
    std = np.ones(center.shape)*(1/len(center))     # std = standard deviations that define the width of each kernel
    W = np.random.random((k+1,1))*2.0 - 1.0
    for i in range( k ):
      G = np.exp( -(X-center[i])**2 / (2*std[i]**2))   # G = Y-cordinates of the i-th gaussian for each time in T
      A = np.hstack((G, A))
      G_weighted = W[i] * G

    weighted_sum = A @ W
    W = np.linalg.pinv( A.T @ A ) @ A.T @ Y
    Y_pred = A @ W




    ax[index].plot( X, Y, '-k', linewidth=3, label="Angle")
    ax[index].plot( X, Y_pred, '--c', linewidth=3, label="Angle_pred")
    ax[index].plot( True )
    ax[index].set_ylabel("Motor " + str(index))
    ax[index].set_xlabel("Time")

    print(f"Weights: {W.T}")

    R = Y_pred - Y
    RSS = np.sum(R**2)
    TSS = np.sum((Y - np.mean(Y))**2)
    R2 = 1 - RSS / TSS
    RMSE = np.sqrt(RSS/n)
    print(f"RSS  = {RSS:.3f}   <-- residual sum of squares" )
    print(f"R^2  = {R2:.3f}   <-- coefficient of determination" )
    print(f"RMSE = {RMSE:.3f}   <-- root mean squared error" )

    for i in range( len(W) ):
        expo = len(W) - i - 1
        print(f"({W[i]} * pow(duration[0], {expo})) + "),


plotMotor(0)
plotMotor(1)
plotMotor(2)
plotMotor(3)
plotMotor(4)
plotMotor(5)






plt.legend()
plt.show()






